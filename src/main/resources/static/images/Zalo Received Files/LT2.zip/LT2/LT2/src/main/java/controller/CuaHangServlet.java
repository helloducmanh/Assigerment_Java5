package controller;

import domain_model.CuaHang;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.commons.beanutils.BeanUtils;
import repository.CuaHangRepository;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@WebServlet({
        "/cua-hang/hien-thi",
        "/cua-hang/view-add",//create
        "/cua-hang/add",//store
        "/cua-hang/detail",//cập nhật edit
        "/cua-hang/delete",
        "/cua-hang/view-update",//
        "/cua-hang/update",
})
public class CuaHangServlet extends HttpServlet {
    private CuaHangRepository chRepo;

    public CuaHangServlet() {
        chRepo = new CuaHangRepository();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("view-add")) {
            this.create(request, response);
        } else if (uri.contains("view-update")) {
            this.edit(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else if(uri.contains("detail")){
            this.detail(request, response);
        }else {
            this.index(request, response);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("add")) {
            this.store(request, response);
        }else if(uri.contains("update")){
            this.update(request, response);
        }else{
            response.sendRedirect("/TEMPLATE_FINAL_war_exploded/cua-hang/hien-thi");
        }
    }

    protected void create(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/fe/view/view-add.jsp").forward(request, response);
    }

    protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        CuaHang ch = this.chRepo.findByMa(ma);
        this.chRepo.delete(ch);
        response.sendRedirect("/TEMPLATE_FINAL_war_exploded/cua-hang/hien-thi");
    }
    protected void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma=request.getParameter("ma");
        CuaHang ch= this.chRepo.findByMa(ma);
       request.setAttribute("ch", ch);
       request.getRequestDispatcher("/fe/view/view-update.jsp").forward(request, response);
    }
    protected void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma=request.getParameter("ma");
        CuaHang ch= this.chRepo.findByMa(ma);
        request.setAttribute("ch", ch);
        request.setAttribute("danhsachCH", this.chRepo.findAll());
        request.getRequestDispatcher("/fe/view/hien-thi.jsp").forward(request, response);
    }
    protected void index(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("danhsachCH", this.chRepo.findAll());
        request.getRequestDispatcher("/fe/view/hien-thi.jsp").forward(request, response);
    }

    protected void store(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            CuaHang ch = new CuaHang();
            BeanUtils.populate(ch, request.getParameterMap());
            if (chRepo.validate(ch)!=null){
                request.setAttribute("result", chRepo.validate(ch));
                request.getRequestDispatcher("/fe/view/view-add.jsp").forward(request, response);
            }else{
                this.chRepo.insert(ch);
            }

        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        response.sendRedirect("/TEMPLATE_FINAL_war_exploded/cua-hang/hien-thi");
    }
    protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String ma= request.getParameter("ma");
            CuaHang ch= this.chRepo.findByMa(ma);
            BeanUtils.populate(ch, request.getParameterMap());
            this.chRepo.update(ch);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        response.sendRedirect("/TEMPLATE_FINAL_war_exploded/cua-hang/hien-thi");
    }
}
